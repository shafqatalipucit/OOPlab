#include <iostream>
#include <math.h>
using namespace std;

// Declaration of the circle class
class circle {
public:
    int x, y;               // x and y coordinates of the circle
    float radius;           // radius of the circle
    static const double PI; // static constant for the value of pi

public:
    // Default constructor
    circle() {
        x = 0;
        y = 0;
        radius = 0;
    }

    // Parameterized constructor to initialize circle with given values
    circle(int x, int y, float radius) {
        // This constructor is left empty. It should be implemented to initialize
        // the x, y, and radius members with the values passed to the constructor.
        setX(x);
        setY(y);
        setRadius(radius);
    }

    // Other constructors

    // Setter function for x coordinate
    void setX(int x) {
        this->x = (x >= -50 && x <= 50) ? x : 0; // Validate x coordinate
    }

    // Getter function for x coordinate
    int getX() {
        return x;
    }

    // Setter function for y coordinate
    void setY(int y) {
        this->y = (y >= -50 && y <= 50) ? y : 0; // Validate y coordinate
    }

    // Getter function for y coordinate
    int getY() {
        return y;
    }

    // Setter function for radius
    void setRadius(int radius) {
        this->radius = (radius >= 1 && radius <= 10) ? radius : 5; // Validate radius
    }

    // Getter function for radius
    float getRadius() {
        return radius;
    }

    // Function to set all circle properties at once
    void setCircle(int x, int y, float radius) {
        this->setX(x);
        this->setY(y);
        this->setRadius(radius);
    }

    // Function to get circle properties from user input
    void getCircle() {
        cout << "Enter x coordinate: ";
        cin >> x;
        cout << "Enter y coordinate: ";
        cin >> y;
        cout << "Enter radius: ";
        cin >> radius;
        setCircle(x, y, radius);
    }

    // Function to display circle properties
    void putCircle() {
        cout << "X coordinate: " << this->getX() << endl;
        cout << "Y coordinate: " << this->getY() << endl;
        cout << "Radius: " << this->getRadius() << endl;
    }

    // Function to calculate and return the area of the circle
    int getArea() {
        return (this->PI * (pow(this->radius, 2)));
    }

    // Function to calculate and return the diameter of the circle
    int getDiameter() {
        return (radius * 2);
    }

    // Function to calculate and return the circumference of the circle
    int getCircumference() {
        return (radius * 2 * PI);
    }

    // Function to add two circles and return the result
    circle addCircle(const circle &obj) {
        return circle(this->getX() + obj.x, this->getY() + obj.y, this->getRadius() + obj.radius);
    }

    // Function to check if two circles are equal
    bool isEqual(const circle &obj) {
        return (this->getX() == obj.x && this->getY() == obj.y && this->getRadius() == obj.radius);
    }

    // Function to find a circle in an array
    int findCircle(circle arr[], int size, const circle &obj) {
        for (int i = 0; i < size; i++) {
            if (arr[i].isEqual(obj)) {
                return i; // Return the index if found
            }
        }
        return -1; // Return -1 if not found
    }

    // Function to update radius of circles in an array
    void updateObjects(circle arr[], int size, const circle &obj) {
        for (int i = 0; i < size; i++) {
            if (arr[i].x == obj.x && arr[i].y == obj.y) {
                arr[i].radius = obj.radius;
            }
        }
    }

    // Destructor
    ~circle() {
        cout << "Destructor is called...." << endl;
    }
};

// Definition of the static constant member variable PI
const double circle::PI = 3.1415;

// Main function where the program starts execution
int main() {
    // Create an instance of the circle class
    circle obj1;
    
    // Set properties of the circle
    obj1.setX(5);
    obj1.setY(6);
    obj1.setRadius(10);
    
    // Display circle properties
    obj1.putCircle();
    
    // Calculate and display area of the circle
    int area = obj1.getArea();
    cout << "Area of the circle is: " << area << endl;
    
    return 0; // Return 0 to indicate successful termination
}
