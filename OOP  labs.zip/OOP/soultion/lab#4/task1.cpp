#include <iostream>
using namespace std;

class RationalNumbers {
private:
    int numerator, denominator;

public:
    // Default constructor
    RationalNumbers() {
        numerator = 0;
        denominator = 1;
    }

    // Parameterized constructor
    RationalNumbers(int numerator, int denominator) {
        // Check if the denominator is non-positive
        if (denominator <= 0) {
            // Set denominator to 1 to avoid division by zero
            this->denominator = 1;
        } else {
            this->denominator = denominator;
        }
        this->numerator = numerator;
    }

    // Copy constructor
    RationalNumbers(const RationalNumbers &obj) {
        this->numerator = obj.numerator;
        this->denominator = obj.denominator;
    }

    // Setter for numerator
    void setNumerator(int num) {
        this->numerator = num;
    }

    // Getter for numerator
    int getNumerator() const {
        return numerator;
    }

    // Setter for denominator
    void setDenominator(int den) {
        // Ensure denominator is non-zero
        if (den != 0) {
            this->denominator = den;
        }
    }

    // Getter for denominator
    int getDenominator() const {
        return denominator;
    }

    // Overload addition operator
    RationalNumbers operator+(const RationalNumbers &obj) {
        int resultNumerator = this->numerator * obj.denominator + obj.numerator * this->denominator;
        int resultDenominator = this->denominator * obj.denominator;
        return RationalNumbers(resultNumerator, resultDenominator);
    }

    // Overload subtraction operator
    RationalNumbers operator-(const RationalNumbers &obj) {
        int resultNumerator = this->numerator * obj.denominator - obj.numerator * this->denominator;
        int resultDenominator = this->denominator * obj.denominator;
        return RationalNumbers(resultNumerator, resultDenominator);
    }

    // Overload multiplication operator
    RationalNumbers operator*(const RationalNumbers &obj) {
        int resultNumerator = this->numerator * obj.numerator;
        int resultDenominator = this->denominator * obj.denominator;
        return RationalNumbers(resultNumerator, resultDenominator);
    }

    // Overload division operator
    RationalNumbers operator/(const RationalNumbers &obj) {
        int resultNumerator = this->numerator * obj.denominator;
        int resultDenominator = this->denominator * obj.numerator;
        return RationalNumbers(resultNumerator, resultDenominator);
    }

    // Overload the logical not (!) operator to check if the rational number is negative
    bool operator!() const {
        return (numerator < 0);
    }

    // Overload unary minus (-) operator to return the negative of the rational number
    RationalNumbers operator-() const {
        return RationalNumbers(-numerator, denominator);
    }

    // Overload less-than (<) operator
    bool operator<(const RationalNumbers &other) const {
        return (numerator * other.denominator < other.numerator * denominator);
    }

    // Overload equality operator
    bool operator==(const RationalNumbers &obj) const {
        return (this->numerator == obj.numerator) && (this->denominator == obj.denominator);
    }

    // Overload stream-insertion operator (<<)
    friend ostream &operator<<(ostream &os, const RationalNumbers &obj) {
        os << obj.numerator << "/" << obj.denominator;
        return os;
    }

    // Overload stream-extraction operator (>>)
    friend istream &operator>>(istream &is, RationalNumbers &obj) {
        is >> obj.numerator >> obj.denominator;
        return is;
    }
};

int main() {
    RationalNumbers obj1(4, 5);
    RationalNumbers obj2(5, 5);
    RationalNumbers resultObj = obj1 + obj2;
    cout << resultObj.getDenominator(); // Corrected typo from 'getDeNumberator' to 'getDenominator'
    return 0;
}
