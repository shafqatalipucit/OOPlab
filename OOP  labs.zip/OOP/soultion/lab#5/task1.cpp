#include <iostream>

class IntegerSet {
private:
    int* array;
    const int size;

public:
    // Constructor to initialize the set with a specified size
    IntegerSet(int s) : size(s) {
        array = new int[size](); // Allocate memory and initialize to 0
    }

    // Copy constructor to create a copy of an existing IntegerSet object
    IntegerSet(const IntegerSet& other) : size(other.size) {
        array = new int[size];  
        for (int i = 0; i < size; ++i) {
            array[i] = other.array[i];
        }
    }

    // Destructor to free the dynamically allocated memory
    ~IntegerSet() {
        delete[] array;
    }

    // Overloaded assignment operator to copy contents from one object to another
    IntegerSet& operator=(const IntegerSet& other) {
        if (this == &other) return *this; // Check for self-assignment

        // Free existing memory
        delete[] array;

        // Allocate new memory and copy contents
        array = new int[size];
        for (int i = 0; i < size; ++i) {
            array[i] = other.array[i];
        }
        return *this;
    }

    // Overloaded equality operator to check if two sets are equal
    bool operator==(const IntegerSet& other) const {
        for (int i = 0; i < size; ++i) {
            if (array[i] != other.array[i]) {
                return false;
            }
        }
        return true;
    }

    // Overloaded logical NOT operator to create a complement of the set
    IntegerSet operator!() const {
        IntegerSet result(size);
        for (int i = 0; i < size; ++i) {
            result.array[i] = !array[i];
        }
        return result;
    }

    // Function to insert an element into the set
    void insertElement(int k) {
        if (k >= 0 && k < size) {
            array[k] = 1;
        } else {
            std::cerr << "Error: Index out of range." << std::endl;
        }
    }

    // Function to delete an element from the set
    void deleteElement(int k) {
        if (k >= 0 && k < size) {
            array[k] = 0;
        } else {
            std::cerr << "Error: Index out of range." << std::endl;
        }
    }

    // Function to compute the union of two sets
    IntegerSet unionOfSets(const IntegerSet& other) const {
        IntegerSet result(size);
        for (int i = 0; i < size; ++i) {
            result.array[i] = array[i] | other.array[i];
        }
        return result;
    }

    // Function to compute the intersection of two sets
    IntegerSet intersectionOfSets(const IntegerSet& other) const {
        IntegerSet result(size);
        for (int i = 0; i < size; ++i) {
            result.array[i] = array[i] & other.array[i];
        }
        return result;
    }

    // Function to check if an element exists in the set
    bool findElement(int key) const {
        if (key >= 0 && key < size) {
            return array[key] == 1;
        } else {
            std::cerr << "Error: Index out of range." << std::endl;
            return false;
        }
    }

    // Friend function to overload the stream insertion operator for output
    friend std::ostream& operator<<(std::ostream& os, const IntegerSet& set) {
        bool isEmpty = true;
        for (int i = 0; i < set.size; ++i) {
            if (set.array[i] == 1) {
                os << i << " ";
                isEmpty = false;
            }
        }
        if (isEmpty) {
            os << "- - -";
        }
        return os;
    }
};

int main() {
    IntegerSet set1(10);
    set1.insertElement(0);
    set1.insertElement(1);
    set1.insertElement(3);
    set1.insertElement(4);
    set1.insertElement(7);
    set1.insertElement(9);

    std::cout << "Set 1: " << set1 << std::endl;

    IntegerSet set2 = set1;
    std::cout << "Set 2: " << set2 << std::endl;

    IntegerSet set3(10);
    set3.insertElement(1);
    set3.insertElement(2);
    set3.insertElement(4);
    set3.insertElement(6);

    std::cout << "Union of Set 1 and Set 3: " << (set1.unionOfSets(set3)) << std::endl;
    std::cout << "Intersection of Set 1 and Set 3: " << (set1.intersectionOfSets(set3)) << std::endl;

    std::cout << "Is element 4 in Set 1? " << (set1.findElement(4) ? "Yes" : "No") << std::endl;

    return 0;
}
