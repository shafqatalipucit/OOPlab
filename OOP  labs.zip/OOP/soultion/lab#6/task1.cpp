#include <iostream>
#include <string>
using namespace std;

class Item
{
    int id, quantity;
    string name;
    float cost;

public:
    Item()
    {
        id = 0;
        quantity = 0;
        cost = 0;
        name = "";
    }
    Item(int id, int quantity, float cost, string name)
    {
        if (id < 0)
        {
            this->id = 0;
        }
        else
        {
            this->id = id;
        }
        if (quantity < 0)
        {
            this->quantity = 0;
        }
        else
        {
            this->quantity = quantity;
        }

        if (cost < 0)
        {
            this->cost = 0;
        }
        else
        {
            this->cost = cost;
        }

        this->name = name;
    }
    Item(const Item &obj)
    {
        this->id = obj.id;
        this->quantity = obj.quantity;
        this->cost = obj.cost;
        this->name = obj.name;
    }

    ~Item()
    {
        cout << "Destructor is called"<<endl;
    }
    void setId(int a)
    {
        if (a < 0)
        {
            this->id = 0;
        }
        else
        {
            this->id = a;
        }
    }
    int getId()
    {
        return this->id;
    }

    void setQuantity(int a)
    {
        if (a < 0)
        {
            this->quantity = 0;
        }
        else
        {
            this->quantity = a;
        }
    }
    int getQuantity()
    {
        return this->quantity;
    }

    void setCost(float a)
    {
        if (a < 0)
        {
            this->cost = 0;
        }
        else
        {
            this->cost = a;
        }
    }
    float getCost()
    {
        return this->cost;
    }

    void setName(string a)
    {

        this->name = a;
    }
    string getName()
    {
        return this->name;
    }
    void Putitem()
    {
        cout << "Cost of the item is : " << this->getCost() << endl;
        cout << "Id of the item is : " << this->getQuantity() << endl;
        cout << "Name of the item is : " << this->getName() << endl;
        cout << "Quantity of the item is : " << this->getId() << endl;
    }
    double getTotalCost()
    {
        if (this->quantity > 0)
        {
            double totalCost = this->getQuantity() * this->getCost();
            cout<<"total cost is :"<<totalCost<<endl;
            return totalCost;
        }
        else
        {
            return 0;
        }
    }
    bool isEqual(const Item& obj1)const {
        if(this->cost==obj1.cost && this->id==obj1.id && this->name== obj1.name && this->quantity==obj1.quantity){
            cout<<"Object are equal"<<endl;
            return true;
        }
        else
        {
            cout<<"Object are not equal"<<endl;
            return false;
            
        }
    }
    void updateName(Item* arr,int size)
    {
        for (int i=0;i<size;i++)
        {
            if(arr[i].id==this->id)
            {
                arr[i].name=this->name;
            }
         }
    }
    static Item getMinimumCostItem(Item* arr,int size)
    {
        Item min=arr[0];
        for(int i=1;i<size;i++)
        {
            if(arr[i].cost<min.cost)
            {
                min=arr[i];
            }
        }
        return min;
    }
    double getAveragePrice(Item* arr,int size)
    {
        int sum,average=0;
        for(int i=0;i<size;i++)
        {
            sum=arr[i].cost+sum;
        }
        average=sum/size;
        return average;
    }
};
int main()
{
    Item obj1(1,2,7,"biscout");
    Item obj2(1,2,7,"biscout");
    Item obj3(1,2,7,"biscout");
    obj1.Putitem();
    obj1.getTotalCost();
    //obj1.isEqual(obj1);
    Item A[]={obj1,obj2,obj3};
    Item obj10=Item::getMinimumCostItem(A,3);
    obj10.Putitem();
    return 0;

}