#include <iostream>
using namespace std;

class Collection
{
    float *data;
    int size;

public:
    // Default Constructor
    Collection() : data(nullptr), size(0) {
        cout << "default constructor called" << endl;
    }

    // Parameterized Constructor
    Collection(int size) : size(size) {
        cout << "parameterized constructor called" << endl;
        data = new float[size];
        for (int i = 0; i < size; i++) {
            data[i] = 0.0f;
        }
    }

    // Copy Constructor
    Collection(const Collection &obj) {
        cout << "copy constructor called" << endl;
        this->size = obj.size;
        data = new float[size];
        for (int i = 0; i < size; i++) {
            data[i] = obj.data[i];
        }
    }

    // Destructor
    ~Collection() {
        cout << "destructor called" << endl;
        delete[] data;
    }

    // Setter
    void setElement(int i, float k) {
        cout << "Setter is called." << endl;
        if (i < 0 || i >= size) {
            cout << "Invalid index." << endl;
        } else {
            data[i] = k;
            cout << k << " inserted successfully at index " << i << endl;
        }
    }

    // Getter
    int getSize() const {
        return size;
    }

    // Assignment Operator
    Collection& operator=(const Collection &obj) {
        if (this == &obj) {
            return *this; // Check for self-assignment
        }
        delete[] data; // Release current data
        size = obj.size;
        data = new float[size];
        for (int i = 0; i < size; i++) {
            data[i] = obj.data[i];
        }
        return *this;
    }

    // Subtraction Operator
    Collection& operator-(const Collection &obj) {
        if (this->size != obj.size) {
            cout << "Subtraction is not possible due to difference in size." << endl;
        } else {
            for (int i = 0; i < size; i++) {
                this->data[i] -= obj.data[i];
            }
        }
        return *this;
    }

    // Unary Plus Operator
    bool operator+() const {
        for (int i = 0; i < size; i++) {
            if (data[i] < 0) {
                return false;
            }
        }
        return true;
    }

    // Index Operator
    float& operator[](int index) {
        if (index < 0 || index >= size) {
            cout << "Index out of bounds." << endl;
            // Return a reference to a static float to handle out-of-bounds access.
            // This is not ideal, but for demonstration purposes.
            static float dummy = 0.0f;
            return dummy;
        }
        return data[index];
    }

    const float& operator[](int index) const {
        if (index < 0 || index >= size) {
            cout << "Index out of bounds." << endl;
            // Return a reference to a static float to handle out-of-bounds access.
            // This is not ideal, but for demonstration purposes.
            static float dummy = 0.0f;
            return dummy;
        }
        return data[index];
    }

    // Output Operator
    friend ostream &operator<<(ostream &os, const Collection &obj);

    // Input Operator
    friend istream &operator>>(istream &is, Collection &obj);
};

// Output Operator Implementation
ostream &operator<<(ostream &os, const Collection &obj) {
    os << "Collection: ";
    for (int i = 0; i < obj.size; i++) {
        os << obj.data[i] << " ";
    }
    return os;
}

// Input Operator Implementation
istream &operator>>(istream &is, Collection &obj) {
    cout << "Enter size: ";
    is >> obj.size;
    delete[] obj.data; // Release any previous data
    obj.data = new float[obj.size];
    cout << "Enter elements for the array:" << endl;
    for (int i = 0; i < obj.size; i++) {
        is >> obj.data[i];
    }
    return is;
}

int main() {
    Collection obj;
    cin >> obj;
    cout << "Entered collection: " << obj << endl;

    Collection obj2(obj);
    cout << "Copied collection: " << obj2 << endl;

    obj2.setElement(2, 10.5f);
    cout << "Updated collection: " << obj2 << endl;

    Collection obj3;
    obj3 = obj2;
    cout << "Assigned collection: " << obj3 << endl;

    cout << "Size of the array is: " << obj.getSize() << endl;

    cout << "Element at index 1: " << obj[1] << endl;
    obj[1] = 42.0f;
    cout << "Updated element at index 1: " << obj[1] << endl;

    Collection obj4(3);
    obj4[0] = 1.2f;
    obj4[1] = 3.4f;
    obj4[2] = 5.6f;

    cout << "New collection (obj4): " << obj4 << endl;
    
    Collection obj5 = obj4 - obj;
    cout << "obj4 - obj: " << obj5 << endl;

    if (+obj5) {
        cout << "All elements in obj5 are positive." << endl;
    } else {
        cout << "Not all elements in obj5 are positive." << endl;
    }

    return 0;
}
