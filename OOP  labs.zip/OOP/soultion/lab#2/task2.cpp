#include <iostream>
using namespace std;
int main()
{
    int size=0,sum=0;
    cout<<"Enter the size of the array:"<<"\n";
    cin>>size;
    float *arr=new float[size];
    for(int i=0;i<size;i++)
    {
        cout<<"Enter value for "<<i+1<<" "<<"element"<<"\n";
        cin>>arr[i];
        sum=sum+arr[i];
    }
    cout<<"Average of the numbers is :"<<sum/size<<"\n";
    delete []arr;
    return 0;
}