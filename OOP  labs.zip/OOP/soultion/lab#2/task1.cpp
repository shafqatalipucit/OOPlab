#include <iostream>
using namespace std;
int main()
{
    int *ptrX = NULL;
    int *ptry = NULL;
    ptrX = new int(2);
    ptry = new int(8);

    cout << "The address of ptrX:" << &ptrX << "\n"
         << "value of ptrX :" << ptrX << " the value of memory location where it points to:" << *ptrX << "\n";
    cout << "The address of ptrX:" << &ptry << "\n"
         << "value of ptrX :" << ptry << " the value of memory location where it points to:" << *ptry << "\n";
    delete ptrX;
    delete ptry;
    return 0;
}