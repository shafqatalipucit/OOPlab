#include <iostream>
using namespace std;
void getPosNeg(const int ar[], const int n_ar, int *&pos, int &n_pos, int *&neg, int &n_neg)
{

    for (int i = 0; i < n_ar; i++)
    {
        if (ar[i] > 0)
        {
            n_pos++;
        }
        else
        {
            n_neg++;
        }
    }
    pos = new int[n_pos];
    neg = new int[n_neg];
    if (n_neg > 0)
    {
        cout << "Negative numbers are:"
             << "\n";
        for (int i = 0; i < n_neg; i++)
        {
            if (ar[i] < 0)
            {
                neg[i] = ar[i];
            }
        }
    }
    // displaying  negative numbers
    for (int i = 0; i < n_neg; i++)
    {
        cout << neg[i] << " ";
    }
    cout << "\n";

    if (n_pos > 0)
    {
        cout << "Positive numbers are:"
             << "\n";
        for (int i = 0; i < n_pos; i++)
        {
            if (ar[i] > 0)

            {
                pos[i] = ar[i];
            }
        }
    }
    for (int i = 0; i < n_pos; i++)
    {
        cout << pos[i] << " ";
    }
    cout << "\n";

    if (n_neg = 0 && n_pos == 0)
    {
        n_pos = 0, n_neg = 0;
        neg = NULL, pos = NULL;
        cout << "not display"
             << "\n";
    }
}
int main()
{
    int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int n_ar = sizeof(array) / sizeof(array[0]);
    int n_pos = 0, n_neg = 0;
    int *pos = new int[n_pos];
    int *neg = new int[n_neg];
    getPosNeg(array, n_ar, pos, n_pos, neg, n_neg);
    return 0;
}