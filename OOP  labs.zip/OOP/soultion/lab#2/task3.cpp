#include <iostream>
using namespace std;
int *getEvenNumbers(const int ar[], const int size, int &evenArraySize)
{
    int count = 0, j = 0;
    for (int i = 0; i < size; i++)
    {
        if (ar[i] % 2 == 0)
        {
            count++;
        }
    }
    if (count == 0)
    {
        evenArraySize = 0;
        return NULL;
    }
    int *evenArray = new int[count];

    for (int i = 0; i < size; i++)
    {
        if (ar[i] % 2 == 0)
        {
            evenArray[j] = ar[i];
            j++;
        }
    }
    evenArraySize = j;
    return evenArray;
}
int main()
{
    int a[]={1,2,3,4,5,6,7,8,9,10};
    int size=sizeof(a)/sizeof(a[0]);
     int evenArraySize=0;
    int *evenarray=getEvenNumbers(a,size,evenArraySize);
    if(evenArraySize>0)
    { 
        for(int i=0;i<evenArraySize;i++)
        {
                cout<<evenarray[i]<<"\n";
        }

    }
    else{
        cout<<" “No Negative Numbers Exist in the Array!”"<<"\n";
    }
    delete []evenarray;
    return 0;
}