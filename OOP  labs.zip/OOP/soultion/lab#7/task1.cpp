#include <iostream>
using namespace std;

class Time
{
private:
    int second, minute, hour;

public:
    Time()
    {
        cout << "Default constructor is called." << endl;
        second = 0;
        minute = 0;
        hour = 0;
    }

    Time(int second, int minute, int hour)
    {
        if (second >= 0 && second <= 59)
        {
            this->second = second;
        }
        else
        {
            this->second = 0;
        }
        if (minute >= 0 && minute <= 59)
        {
            this->minute = minute;
        }
        else
        {
            this->minute = 0;
        }
        if (hour >= 0 && hour <= 59)
        {
            this->hour = hour;
        }
        else
        {
            this->hour = 0;
        }
    }

    Time(int minute, int hour)
    {

        if (minute >= 0 && minute <= 59)
        {
            this->minute = minute;
        }
        else
        {
            this->minute = 0;
        }
        if (hour >= 0 && hour <= 59)
        {
            this->hour = hour;
        }
        else
        {
            this->hour = 0;
        }
    }

    void setSecond(int second)
    {
        if (second >= 0 && second <= 59)
        {
            this->second = second;
        }
        else
        {
            this->second = 0;
        }
    }

    int getSecond()
    {
        return second;
    }

    void setMinute(int minute)
    {
        if (minute >= 0 && minute <= 59)
        {
            this->minute = minute;
        }
        else
        {
            this->minute = 0;
        }
    }
    int getMinute()
    {
        return minute;
    }

    void setHour(int hour)
    {
        if (hour >= 0 && hour <= 59)
        {
            this->hour = hour;
        }
        else
        {
            this->hour = 0;
        }
    }
    int gethour()
    {
        return hour;
    }
    Time &operator++()
    {
        ++second;
        if (second >= 60)
        {
            second = 0;
            minute++;
            if (minute >= 60)
            {
                minute = 0;
                hour++;
                if (hour >= 24)
                {
                    hour = 0;
                }
            }
        }
        return *this;
    }
    Time operator++(int)
    {
        Time temp = *this;
        ++(*this);
        return *this;
    }
    Time &operator--()
    {
        ++second;
        if (second <= 0)
        {
            second = 0;
            minute--;
            if (minute <= 0)
            {
                minute = 0;
                hour--;
                if (hour <= 0)
                {
                    hour = 0;
                }
            }
        }
        return *this;
    }
    Time operator--(int)
    {
        Time temp = *this;
        --(*this);
        return *this;
    }

    friend ostream &operator<<(ostream &os, const Time &obj);
    friend istream &operator>>(istream &is, Time &obj);
    ~Time()
    {
        cout << "Destructor called ." << endl;
    }

    double operator-(Time obj)
    {
        double second;
        cout << "Number  of seconds between two dates are :" << endl;
        if (this->hour >= obj.hour)
        {
            second = (this->hour - obj.hour) * 3600 + (this->minute - obj.minute) * 60 + this->second - obj.second;
        }
        else
        {
            cout << "left side hours are greater." << endl;
        }
        return second;
    }
    bool operator+()
    {
        if (this->hour>=9 && this->hour<=17)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};
ostream &operator<<(ostream &os, const Time &obj)
{
    os << "Time is :" << endl;
    os << obj.second << ":" << obj.minute << ":" << obj.hour << endl;
    return os;
}

istream &operator>>(istream &is, Time &obj)
{

    cout << "Enter seconds" << endl;
    is >> obj.second;
    cout << "Enter minutes" << endl;
    is >> obj.minute;
    cout << "Enter houra" << endl;
    is >> obj.hour;
    return is;
}

int main()
{
    Time obj;
    return 0;
}